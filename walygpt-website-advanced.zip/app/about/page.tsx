import { Mail, MessageCircle, ArrowLeft, Sparkles } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* خلفية متحركة */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -inset-10 opacity-30">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
          <div className="absolute top-3/4 right-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-2000"></div>
          <div className="absolute bottom-1/4 left-1/2 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-4000"></div>
        </div>
      </div>

      {/* المحتوى */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="max-w-2xl w-full">
          {/* زر العودة */}
          <div className="mb-8">
            <Link href="/">
              <Button className="bg-white/10 hover:bg-white/20 text-white border border-white/20 backdrop-blur-md rounded-xl transition-all duration-300">
                <ArrowLeft className="w-4 h-4 mr-2" />
                العودة للشات
              </Button>
            </Link>
          </div>

          {/* بطاقة التعريف */}
          <div className="backdrop-blur-md bg-white/10 rounded-3xl border border-white/20 p-8 shadow-2xl">
            {/* العنوان */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center gap-3 mb-4">
                <Sparkles className="w-6 h-6 text-cyan-400 animate-pulse" />
                <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-blue-400 bg-clip-text text-transparent">
                  حول WALYGPT
                </h1>
                <Sparkles className="w-6 h-6 text-purple-400 animate-pulse" />
              </div>
            </div>

            {/* معلومات المطور */}
            <div className="text-center space-y-6">
              <div className="space-y-4">
                <p className="text-xl text-gray-200 leading-relaxed">تم تصميم هذا الموقع بواسطة</p>
                <h2 className="text-2xl md:text-3xl font-bold text-white">مصطفى سعيد والي</h2>
                <p className="text-lg text-cyan-300 font-medium">صيدلي إكلينيكي</p>
              </div>

              {/* وصف الموقع */}
              <div className="bg-white/5 rounded-2xl p-6 border border-white/10">
                <p className="text-gray-300 leading-relaxed text-lg">
                  WALYGPT هو مساعد ذكي مصري دمه خفيف. يتميز بأسلوبه الساخر والمرح في الرد على الأسئلة، مع الحفاظ على دقة
                  المعلومات. هيساعدك في أي مجال بس متزعلش من طريقة رده!
                </p>
              </div>

              {/* معلومات التواصل */}
              <div className="space-y-6 mt-8">
                <h3 className="text-xl font-semibold text-white mb-4">للتواصل والاستفسارات</h3>

                <div className="grid md:grid-cols-2 gap-4">
                  {/* واتساب */}
                  <a href="https://wa.me/201040521686" target="_blank" rel="noopener noreferrer" className="group">
                    <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-400/30 rounded-2xl p-6 transition-all duration-300 hover:scale-105 hover:shadow-lg backdrop-blur-sm">
                      <div className="flex items-center gap-4">
                        <div className="bg-green-500/20 p-3 rounded-xl group-hover:bg-green-500/30 transition-colors">
                          <MessageCircle className="w-6 h-6 text-green-400" />
                        </div>
                        <div className="text-right">
                          <p className="text-green-300 font-medium">واتساب</p>
                          <p className="text-gray-300 text-sm">+201040521686</p>
                        </div>
                      </div>
                    </div>
                  </a>

                  {/* إيميل */}
                  <a href="mailto:mwaly8715@gmail.com" className="group">
                    <div className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border border-blue-400/30 rounded-2xl p-6 transition-all duration-300 hover:scale-105 hover:shadow-lg backdrop-blur-sm">
                      <div className="flex items-center gap-4">
                        <div className="bg-blue-500/20 p-3 rounded-xl group-hover:bg-blue-500/30 transition-colors">
                          <Mail className="w-6 h-6 text-blue-400" />
                        </div>
                        <div className="text-right">
                          <p className="text-blue-300 font-medium">إيميل</p>
                          <p className="text-gray-300 text-sm">mwaly8715@gmail.com</p>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>

              {/* ملاحظة مهمة */}
              <div className="bg-yellow-500/10 border border-yellow-400/30 rounded-2xl p-6 mt-8">
                <p className="text-yellow-200 text-sm leading-relaxed">
                  <strong>ملاحظة مهمة:</strong> هذا المساعد الذكي بيتميز بأسلوبه الساخر والمرح، لكن المعلومات المقدمة
                  دقيقة وموثوقة. متزعلش من طريقة الرد، دي شخصيته!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
