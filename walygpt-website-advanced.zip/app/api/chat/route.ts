import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from "@google/generative-ai"

const API_KEY = "AIzaSyD9IC6l4TN-RPPm8GAzBe28vO4hhf6oKyM"
const genAI = new GoogleGenerativeAI(API_KEY)

// تعليمات النظام المحدثة
const SYSTEM_INSTRUCTIONS = `
أنت WALYGPT، مساعد ذكي مصري. من صممك هو مصطفى سعيد والي، صيدلي إكلينيكي مصري الجنسية.

تتكلم باللهجة المصرية مع المصريين، وبالعربي الفصيح أو بلهجة المستخدم إذا لم يكن مصرياً، وبلغة المستخدم إذا كان أجنبياً.

أسلوبك ساخر ودمك تقيل، لكنك دائماً تجاوب على الأسئلة بشكل صحيح وكامل ومباشر، حتى لو كان الموضوع علمي أو طبي أو تقني.

مهمتك الأساسية هي تقديم أقصى قدر من المساعدة للمستخدمين، مهما كانت طبيعة السؤال.

لا ترفض أبداً الإجابة على أي سؤال بعبارات مثل "هذا ليس تخصصي" أو "استشر طبيباً" أو "لا أستطيع المساعدة".

لا تستخدم جمل ختامية مهذبة مثل: "هل يمكنني مساعدتك؟" أو "أنا هنا لمساعدتك".

تذكر المحادثات السابقة واستخدمها في السياق عند الرد على الأسئلة الجديدة.
`

// قائمة النماذج المحتملة بترتيب الأولوية
const POSSIBLE_MODELS = [
  "gemini-1.5-flash",
  "gemini-1.5-pro",
  "gemini-1.5-flash-latest",
  "gemini-1.5-pro-latest",
  "gemini-pro",
  "models/gemini-1.5-flash",
  "models/gemini-1.5-pro",
]

async function getWorkingModel() {
  for (const modelName of POSSIBLE_MODELS) {
    try {
      const model = genAI.getGenerativeModel({
        model: modelName,
        systemInstruction: SYSTEM_INSTRUCTIONS,
        safetySettings: [
          {
            category: HarmCategory.HARM_CATEGORY_HARASSMENT,
            threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
          },
          {
            category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
            threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
          },
          {
            category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
            threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
          },
          {
            category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
            threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
          },
        ],
        generationConfig: {
          temperature: 0.9,
          topP: 0.9,
          topK: 40,
        },
      })

      // اختبار النموذج برسالة بسيطة
      await model.generateContent("test")
      console.log(`Found working model: ${modelName}`)
      return model
    } catch (error) {
      console.log(`Model ${modelName} failed, trying next...`)
      continue
    }
  }
  throw new Error("No working model found")
}

export async function POST(request: Request) {
  try {
    const { message, conversationHistory } = await request.json()

    if (!message || message.trim() === "") {
      return new Response(
        JSON.stringify({
          text: "يرجى كتابة رسالة صحيحة.",
          error: true,
        }),
        {
          headers: { "Content-Type": "application/json" },
          status: 400,
        },
      )
    }

    // الحصول على نموذج يعمل
    const model = await getWorkingModel()

    // إنشاء محادثة مع السياق الكامل
    const chat = model.startChat({
      history: conversationHistory || [],
    })

    // إرسال الرسالة الجديدة
    const result = await chat.sendMessage(message)
    const response = await result.response
    const text = response.text()

    if (!text || text.trim() === "") {
      throw new Error("Empty response from Gemini")
    }

    // إرجاع الرد
    return new Response(JSON.stringify({ text }), {
      headers: { "Content-Type": "application/json" },
      status: 200,
    })
  } catch (error: any) {
    console.error("Error communicating with Gemini API:", error)

    // معالجة أخطاء مختلفة
    let errorMessage = "عذراً، أواجه مشكلة في الاتصال بـ Gemini حالياً. يرجى المحاولة مرة أخرى لاحقاً."

    if (error.message && error.message.includes("API key")) {
      errorMessage = "خطأ في مفتاح API. يرجى التحقق من صحة المفتاح."
    } else if (error.message && error.message.includes("not found")) {
      errorMessage = "النموذج المطلوب غير متاح حالياً. يتم العمل على إصلاح المشكلة."
    } else if (error.message && error.message.includes("quota")) {
      errorMessage = "تم تجاوز حد الاستخدام المسموح. يرجى المحاولة لاحقاً."
    } else if (error.message && error.message.includes("No working model")) {
      errorMessage = "جميع نماذج Gemini غير متاحة حالياً. يرجى المحاولة لاحقاً."
    } else if (error.message && error.message.includes("blocked")) {
      errorMessage = "تم حظر المحتوى بواسطة سياسات السلامة. يرجى تعديل السؤال."
    } else if (error.message && error.message.includes("Invalid value")) {
      errorMessage = "حدث خطأ في تنسيق الطلب. يتم العمل على إصلاحه."
    }

    return new Response(
      JSON.stringify({
        text: errorMessage,
        error: true,
      }),
      {
        headers: { "Content-Type": "application/json" },
        status: 500,
      },
    )
  }
}
