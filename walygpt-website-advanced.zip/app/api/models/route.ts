import { GoogleGenerativeAI } from "@google/generative-ai"

const API_KEY = "AIzaSyD9IC6l4TN-RPPm8GAzBe28vO4hhf6oKyM"
const genAI = new GoogleGenerativeAI(API_KEY)

export async function GET() {
  try {
    // محاولة الحصول على قائمة النماذج المتاحة
    const models = await genAI.listModels()

    return new Response(
      JSON.stringify({
        models: models.map((model) => ({
          name: model.name,
          displayName: model.displayName,
          description: model.description,
        })),
      }),
      {
        headers: { "Content-Type": "application/json" },
        status: 200,
      },
    )
  } catch (error) {
    console.error("Error listing models:", error)
    return new Response(
      JSON.stringify({
        error: "Unable to fetch models",
        message: error instanceof Error ? error.message : "Unknown error",
      }),
      {
        headers: { "Content-Type": "application/json" },
        status: 500,
      },
    )
  }
}
