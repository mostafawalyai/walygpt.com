"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Send, Mic, Sparkles, Code, BookOpen, MessageSquare, PenTool, Search, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

// هذا هو الرابط الخاص بـ Google Apps Script Web App الذي سيستقبل سجلات المحادثات
const GOOGLE_SHEET_LOGGER_URL =
  "https://script.google.com/macros/s/AKfycbyNM1QRiU38Tc2OdqmxrtJq4uQn2wVPgv-26g3itk-FzRFd_yuLB2aBE239lhlA9_AxOQ/exec"

// المفتاح المستخدم لتخزين سجل المحادثة في localStorage
const CONVERSATION_HISTORY_KEY = "geminiChatHistory"

interface Message {
  id: string
  text: string
  isUser: boolean
  timestamp: Date
}

interface ConversationEntry {
  parts: Array<{ text: string }>
  role: "user" | "model"
}

// دالة لتحميل سجل المحادثة من localStorage
function loadConversationHistory(): ConversationEntry[] {
  try {
    if (typeof window !== "undefined") {
      const history = localStorage.getItem(CONVERSATION_HISTORY_KEY)
      return history ? JSON.parse(history) : []
    }
    return []
  } catch (e) {
    console.error("Error loading conversation history:", e)
    return []
  }
}

// دالة لحفظ سجل المحادثة في localStorage
function saveConversationHistory(history: ConversationEntry[]) {
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(CONVERSATION_HISTORY_KEY, JSON.stringify(history))
    }
  } catch (e) {
    console.error("Error saving conversation history:", e)
  }
}

// دالة مساعدة لتسجيل رسائل المحادثة إلى Google Sheet
async function logConversation(userMessage: string, botResponse: string) {
  try {
    const response = await fetch(GOOGLE_SHEET_LOGGER_URL, {
      method: "POST",
      mode: "no-cors",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        user_message: userMessage,
        bot_response: botResponse,
        timestamp: new Date().toISOString(),
      }),
    })
    console.log("Conversation logging request sent to Google Sheet.")
  } catch (error) {
    console.error("Error logging conversation:", error)
  }
}

export default function HomePage() {
  // تهيئة سجل المحادثة عند بدء تشغيل التطبيق
  const [conversationHistory, setConversationHistory] = useState<ConversationEntry[]>([])
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "أهلاً بيك! أنا WALYGPT، مساعدك الذكي المصري اللي هيرد على كل أسئلتك... بس متزعلش لو الرد مش على مزاجك 😏",
      isUser: false,
      timestamp: new Date(),
    },
  ])
  const [inputText, setInputText] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const chatContainerRef = useRef<HTMLDivElement>(null)

  // تحميل سجل المحادثة عند تحميل المكون
  useEffect(() => {
    const loadedHistory = loadConversationHistory()
    setConversationHistory(loadedHistory)

    // إذا كان هناك سجل محادثة محفوظ، قم بتحويله إلى رسائل لعرضها
    if (loadedHistory.length > 0) {
      const convertedMessages: Message[] = [
        {
          id: "1",
          text: "أهلاً بيك! أنا WALYGPT، مساعدك الذكي المصري اللي هيرد على كل أسئلتك... بس متزعلش لو الرد مش على مزاجك 😏",
          isUser: false,
          timestamp: new Date(),
        },
      ]

      loadedHistory.forEach((entry, index) => {
        convertedMessages.push({
          id: `history-${index}`,
          text: entry.parts[0].text,
          isUser: entry.role === "user",
          timestamp: new Date(),
        })
      })

      setMessages(convertedMessages)
    }
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // دالة لمسح سجل المحادثة
  const clearChatHistory = () => {
    setConversationHistory([])
    saveConversationHistory([])
    setMessages([
      {
        id: "1",
        text: "أهلاً بيك! أنا WALYGPT، مساعدك الذكي المصري اللي هيرد على كل أسئلتك... بس متزعلش لو الرد مش على مزاجك 😏",
        isUser: false,
        timestamp: new Date(),
      },
    ])
    console.log("Chat history cleared.")
  }

  const handleSendMessage = async () => {
    if (!inputText.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isUser: true,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    const currentInput = inputText
    setInputText("")
    setIsTyping(true)

    try {
      // 1. إضافة رسالة المستخدم الحالية إلى سجل المحادثة
      const newUserEntry: ConversationEntry = {
        parts: [{ text: currentInput }],
        role: "user",
      }

      const updatedHistory = [...conversationHistory, newUserEntry]
      setConversationHistory(updatedHistory)

      // 2. إرسال سجل المحادثة بالكامل إلى API
      let response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: currentInput,
          conversationHistory: updatedHistory, // إرسال السياق الكامل
        }),
      })

      // إذا فشل، جرب النسخة الاحتياطية
      if (!response.ok) {
        console.log("Primary API failed, trying fallback...")
        response = await fetch("/api/chat-fallback", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            message: currentInput,
            conversationHistory: updatedHistory,
          }),
        })
      }

      const data = await response.json()

      if (!response.ok || data.error) {
        throw new Error(data.text || "فشل الاتصال بالخادم")
      }

      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: data.text,
        isUser: false,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, aiResponse])

      // 3. إضافة رد البوت إلى سجل المحادثة
      const newBotEntry: ConversationEntry = {
        parts: [{ text: data.text }],
        role: "model",
      }

      const finalHistory = [...updatedHistory, newBotEntry]
      setConversationHistory(finalHistory)

      // 4. حفظ سجل المحادثة المحدث في localStorage
      saveConversationHistory(finalHistory)

      // تسجيل المحادثة في Google Sheet
      await logConversation(currentInput, data.text)
    } catch (error) {
      console.error("Error:", error)

      // رسالة خطأ للمستخدم
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: error instanceof Error ? error.message : "عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.",
        isUser: false,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])

      // إزالة رسالة المستخدم الأخيرة من السجل إذا حدث خطأ
      setConversationHistory((prev) => prev.slice(0, -1))
      saveConversationHistory(conversationHistory.slice(0, -1))

      // تسجيل رسائل الخطأ أيضاً في Google Sheet للمراجعة
      const errorText = error instanceof Error ? error.message : "خطأ غير معروف"
      await logConversation(currentInput, `[خطأ] ${errorText}`)
    } finally {
      setIsTyping(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  // تعديل ارتفاع مربع النص تلقائياً
  const adjustTextareaHeight = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const textarea = e.target
    textarea.style.height = "auto"
    textarea.style.height = `${Math.min(textarea.scrollHeight, 150)}px`
    setInputText(textarea.value)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* خلفية متحركة */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -inset-10 opacity-30">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
          <div className="absolute top-3/4 right-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-2000"></div>
          <div className="absolute bottom-1/4 left-1/2 w-96 h-96 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse animation-delay-4000"></div>
        </div>

        {/* شبكة رقمية متحركة */}
        <div className="absolute inset-0 opacity-20">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: "radial-gradient(circle, rgba(156, 146, 172, 0.3) 1px, transparent 1px)",
              backgroundSize: "30px 30px",
              animation: "float 6s ease-in-out infinite",
            }}
          ></div>
        </div>
      </div>

      {/* المحتوى الرئيسي */}
      <div className="relative z-10 flex flex-col h-screen">
        {/* Header */}
        <header className="text-center py-4 px-4">
          <div className="inline-flex items-center gap-3 mb-2">
            <Sparkles className="w-6 h-6 text-cyan-400 animate-pulse" />
            <h1 className="text-3xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-blue-400 bg-clip-text text-transparent animate-pulse">
              WALYGPT
            </h1>
            <Sparkles className="w-6 h-6 text-purple-400 animate-pulse" />
          </div>
          <p className="text-gray-300 text-base md:text-lg font-light">مساعدك الذكي المصري اللي دمه خفيف</p>

          {/* أيقونات تعبر عن تنوع الاستخدامات */}
          <div className="flex justify-center gap-4 mt-2">
            <Code className="w-4 h-4 text-blue-400" />
            <BookOpen className="w-4 h-4 text-green-400" />
            <MessageSquare className="w-4 h-4 text-yellow-400" />
            <PenTool className="w-4 h-4 text-pink-400" />
            <Search className="w-4 h-4 text-purple-400" />
          </div>
        </header>

        {/* منطقة الشات */}
        <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full px-4 overflow-hidden">
          {/* زر مسح المحادثة */}
          <div className="flex justify-end mb-2">
            <Button
              onClick={clearChatHistory}
              className="bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-400/30 rounded-xl p-2 transition-all duration-300 text-xs"
              title="مسح المحادثة"
            >
              <Trash2 className="w-4 h-4 mr-1" />
              مسح المحادثة
            </Button>
          </div>

          {/* رسائل الشات */}
          <div
            ref={chatContainerRef}
            className="flex-1 overflow-y-auto mb-4 space-y-4 backdrop-blur-sm bg-white/5 rounded-3xl border border-white/10 p-4 shadow-2xl"
            style={{ maxHeight: "calc(100vh - 280px)" }}
          >
            <div className="min-h-full">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.isUser ? "justify-end" : "justify-start"} mb-4`}>
                  <div
                    className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-2xl backdrop-blur-md border shadow-lg ${
                      message.isUser
                        ? "bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border-blue-400/30 text-blue-100"
                        : "bg-gradient-to-r from-purple-500/20 to-pink-500/20 border-purple-400/30 text-purple-100"
                    }`}
                  >
                    <p className="text-sm md:text-base leading-relaxed whitespace-pre-wrap break-words">
                      {message.text}
                    </p>
                    <span className="text-xs opacity-70 mt-2 block">
                      {message.timestamp.toLocaleTimeString("ar-EG", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start mb-4">
                  <div className="max-w-xs px-4 py-3 rounded-2xl backdrop-blur-md bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-400/30">
                    <div className="flex space-x-2">
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce animation-delay-200"></div>
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce animation-delay-400"></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </div>

          {/* صندوق الإدخال */}
          <div className="backdrop-blur-md bg-white/10 rounded-2xl border border-white/20 p-3 shadow-2xl mb-3">
            <div className="flex items-end gap-2">
              <div className="flex-1 relative">
                <textarea
                  value={inputText}
                  onChange={adjustTextareaHeight}
                  onKeyPress={handleKeyPress}
                  placeholder="اكتب سؤالك هنا... بس متزعلش من الرد 😏"
                  className="w-full bg-transparent text-white placeholder-gray-400 border-none outline-none resize-none text-base p-2 rounded-xl"
                  style={{ minHeight: "40px", maxHeight: "150px" }}
                  disabled={isTyping}
                  rows={1}
                />
              </div>

              <Button
                onClick={handleSendMessage}
                disabled={!inputText.trim() || isTyping}
                className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white rounded-xl p-2 transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                <Send className="w-5 h-5" />
              </Button>

              <Button
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-xl p-2 transition-all duration-300 transform hover:scale-105 shadow-lg"
                disabled={true}
              >
                <Mic className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* رابط صفحة التعريف */}
          <footer className="text-center py-1">
            <Link href="/about" className="text-gray-400 hover:text-cyan-400 transition-colors duration-300 text-xs">
              حول المطور
            </Link>
            <p className="text-xs text-gray-500 mt-1">تم التطوير بواسطة مصطفى سعيد والي</p>
          </footer>
        </div>
      </div>
    </div>
  )
}
